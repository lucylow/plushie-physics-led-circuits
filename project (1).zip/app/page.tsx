import { GameBoard } from './game-board'

export default function Page() {
  return <GameBoard />
}
