import { Award, Check, ChevronRight, CircuitBoard, PawPrint, Scissors, Search, Sparkles, WandSparkles, Zap } from 'lucide-react'

type GameLoopProps = {
  hasThread: boolean
  allComponentsPresent: boolean
  plushieName: string
  problem: string
  ability: string
  componentSummary: string
  topology: 'single' | 'parallel'
  threadLength: number
  testResult: 'dim' | 'success' | null
  lastFault: { threadLength: number; currentMa: number } | null
  completed: boolean
}

type StepState = 'complete' | 'current' | 'upcoming'

const stages = [
  {
    title: 'Meet & discover',
    icon: PawPrint,
    steps: [
      { id: 'adopt', title: 'Adopt a plushie', detail: 'Pip is your new lab partner.' },
      { id: 'mystery', title: 'Find the mystery', detail: 'Her heart light has gone dim.' },
    ],
  },
  {
    title: 'Choose & design',
    icon: CircuitBoard,
    steps: [
      { id: 'choose', title: 'Choose components', detail: 'Pick a battery, thread, and LED.' },
      { id: 'design', title: 'Design a circuit', detail: 'Connect the parts into a loop.' },
    ],
  },
  {
    title: 'Sew & test',
    icon: Scissors,
    steps: [
      { id: 'sew', title: 'Sew the pathway', detail: 'Stitch conductive thread through Pip.' },
      { id: 'test', title: 'Test the circuit', detail: 'Send current around the full loop.' },
    ],
  },
  {
    title: 'Debug & improve',
    icon: Search,
    steps: [
      { id: 'debug', title: 'Diagnose a failure', detail: 'Check for loose stitches or a reversed LED.' },
      { id: 'improve', title: 'Improve the design', detail: 'Shorter thread means less resistance.' },
    ],
  },
  {
    title: 'Spark & unlock',
    icon: WandSparkles,
    steps: [
      { id: 'ability', title: 'Activate Pip’s ability', detail: 'Watch her heart shine bright.' },
      { id: 'badge', title: 'Earn a badge', detail: 'Unlock a new laboratory together.' },
    ],
  },
]

export function GameLoop({ hasThread, allComponentsPresent, plushieName, problem, ability, componentSummary, topology, threadLength, testResult, lastFault, completed }: GameLoopProps) {
  const states: Record<string, StepState> = {
    adopt: 'complete',
    mystery: 'complete',
    choose: allComponentsPresent ? 'complete' : 'current',
    design: allComponentsPresent ? 'complete' : 'upcoming',
    sew: hasThread ? 'complete' : allComponentsPresent ? 'current' : 'upcoming',
    test: testResult || lastFault ? 'complete' : allComponentsPresent ? 'current' : 'upcoming',
    debug: completed || lastFault ? 'complete' : 'upcoming',
    improve: completed ? 'complete' : lastFault ? 'current' : 'upcoming',
    ability: completed ? 'complete' : 'upcoming',
    badge: completed ? 'complete' : 'upcoming',
  }
  const completedSteps = Object.values(states).filter((state) => state === 'complete').length

  return (
    <section className="game-loop-card" aria-labelledby="game-loop-title">
      <div className="loop-heading">
        <div><span className="card-kicker">THE LITTLE SPARKS GAME LOOP</span><h2 id="game-loop-title">From mystery to magic</h2><p>Every plushie adventure follows the same curious, hands-on path.</p></div>
        <span className="loop-progress"><Sparkles size={13} aria-hidden="true" /> {completedSteps} / 10 steps</span>
      </div>
      <div className="loop-stages">
        {stages.map(({ title, icon: Icon, steps }, stageIndex) => (
          <div className="loop-stage" key={title}>
            <div className="loop-stage-title"><span className="loop-stage-icon"><Icon size={15} aria-hidden="true" /></span><span>{title}</span></div>
            <ol className="loop-steps">
              {steps.map((step, stepIndex) => {
                const state = states[step.id]
                const number = stages.slice(0, stageIndex).reduce((count, stage) => count + stage.steps.length, 0) + stepIndex + 1
                return (
                  <li className={`loop-step ${state}`} key={step.id}>
                    <span className="loop-step-marker">{state === 'complete' ? <Check size={12} aria-hidden="true" /> : number}</span>
                    <div><strong>{step.id === 'adopt' ? `Adopt ${plushieName}` : step.id === 'ability' ? `Activate ${plushieName}’s ability` : step.title}</strong><small>{step.id === 'adopt' ? `${plushieName} is your new lab partner.` : step.id === 'mystery' ? problem : step.id === 'choose' ? `Choose ${componentSummary}.` : step.id === 'design' && topology === 'parallel' ? 'Connect both protected branches in parallel; each gets full battery voltage.' : step.id === 'sew' ? `Stitch conductive thread through ${plushieName}’s fabric.` : step.id === 'test' && topology === 'parallel' ? 'Compare current through the left and right whisker branches.' : step.id === 'ability' ? `Wake the ${ability}.` : step.id === 'debug' && lastFault && !completed ? `Mock reading: ${lastFault.currentMa} mA per branch. The ${lastFault.threadLength} cm thread in each branch dims both LEDs.` : step.id === 'debug' && completed ? topology === 'parallel' ? 'Both parallel branches passed; current flows evenly.' : 'Closed loop confirmed; current flows cleanly.' : step.id === 'improve' && lastFault && !completed ? topology === 'parallel' ? `Shorten each ${threadLength} cm branch stitch to brighten both LEDs.` : `Shorten the pathway from ${threadLength} cm and retest.` : step.detail}</small></div>
                  </li>
                )
              })}
            </ol>
            {stageIndex < stages.length - 1 && <ChevronRight className="loop-connector" size={13} aria-hidden="true" />}
          </div>
        ))}
      </div>
      <div className="loop-footnote"><Zap size={14} fill="currentColor" aria-hidden="true" /><span>{lastFault && !completed ? topology === 'parallel' ? 'Fault found: long thread in both whisker branches. Shorten each stitch, then retest.' : 'Fault found: the long conductive thread. Shorten it in your toolkit, then retest.' : completed ? `${plushieName}’s ${ability} is awake. Your next experiment is waiting in the Circuit Sewing Studio.` : `Build ${plushieName}’s circuit above to light up a special ability.`}</span><span className="loop-badge"><Award size={13} aria-hidden="true" /> FIRST SPARK</span></div>
    </section>
  )
}
