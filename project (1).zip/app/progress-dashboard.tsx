import Image from 'next/image'
import { ArrowUpRight, Award, BatteryCharging, BookOpen, Check, Clock3, CircuitBoard, Flame, LockKeyhole, PawPrint, Scissors, Sparkles, Star, Zap } from 'lucide-react'

const stats = [
  { label: 'Spark points', value: '480', completedValue: '530', note: '+80 this week', completedNote: '+130 this week', icon: Zap, tone: 'lilac' },
  { label: 'Builds tested', value: '06', completedValue: '07', note: '2 more than last week', completedNote: 'A new circuit tested', icon: BatteryCharging, tone: 'peach' },
  { label: 'Day streak', value: '03', completedValue: '03', note: 'Your longest is 5 days', completedNote: 'Your longest is 5 days', icon: Flame, tone: 'gold' },
  { label: 'Badges earned', value: '02', completedValue: '03', note: 'Conductivity + Curious', completedNote: 'First Spark badge added', icon: Award, tone: 'mint' },
]

const labs = [
  { number: '01', name: 'Conductivity Garden', detail: '3 of 4 experiments', state: 'current' },
  { number: '02', name: 'Circuit Sewing Studio', detail: 'Available after this experiment', state: 'unlocked' },
  { number: '03', name: 'Resistance Repair Clinic', detail: 'Unlock after lab 2', state: 'locked' },
  { number: '04', name: 'Electromagnetic Garage', detail: 'Build a magnetic mover', state: 'locked' },
  { number: '05', name: 'Sensor Pet Sanctuary', detail: 'Wake a sleepy sensor pal', state: 'locked' },
  { number: '06', name: 'Microcontroller Magic Room', detail: 'Program a plushie’s wink', state: 'locked' },
  { number: '07', name: 'Advanced Plushie Research Center', detail: 'Design an original circuit', state: 'locked' },
]

const friends = [
  { name: 'Pip', type: 'Lavender bunny', mood: 'Waiting for a spark', image: '/plushie-hero.png', tone: 'friend-lilac', progress: 'In progress' },
  { name: 'Miso', type: 'Peachy cat', mood: 'Heart light repaired', image: '/plushie-miso.png', tone: 'friend-peach', progress: 'Circuit complete' },
  { name: 'Orbit', type: 'Sleepy moon bear', mood: 'Ready for a new build', image: '/plushie-orbit.png', tone: 'friend-mint', progress: 'New friend' },
  { name: 'Nori', type: 'Mint sea turtle', mood: 'Dreaming of a pressure sensor', image: '/plushie-nori.png', tone: 'friend-mint', progress: 'Idea sketch' },
  { name: 'Button', type: 'Sunny fox', mood: 'Wants to ring a tiny bell', image: '/plushie-button.png', tone: 'friend-peach', progress: 'Idea sketch' },
  { name: 'Fizz', type: 'Sky-blue axolotl', mood: 'Testing two sensor leads', image: '/plushie-fizz.png', tone: 'friend-blue', progress: 'Sensor sketch' },
  { name: 'Daisy', type: 'Blush lamb', mood: 'Hoping to hear a tiny chime', image: '/plushie-daisy.png', tone: 'friend-rose', progress: 'New friend' },
  { name: 'Pebble', type: 'Lilac hedgehog', mood: 'Mapping a compass patch', image: '/plushie-pebble.png', tone: 'friend-lilac', progress: 'Prototype' },
]

const activity = [
  { title: 'Miso’s moonlight circuit', detail: 'Closed a loop with 2 LEDs', time: 'Yesterday', icon: Check, tone: 'mint' },
  { title: 'Conductivity badge earned', detail: 'Finished your first circuit test', time: 'Mon', icon: Award, tone: 'gold' },
  { title: 'A new friend arrived', detail: 'Orbit joined the plushie crew', time: 'Sun', icon: PawPrint, tone: 'lilac' },
  { title: 'Thread-length experiment', detail: 'Compared 5 cm and 30 cm stitches', time: 'Fri', icon: Scissors, tone: 'peach' },
  { title: 'Nori’s shell sensor idea', detail: 'Saved a pressure-sensor sketch', time: 'Thu', icon: Sparkles, tone: 'mint' },
  { title: 'Button’s tiny doorbell plan', detail: 'Added a buzzer to the idea board', time: 'Wed', icon: Zap, tone: 'gold' },
  { title: 'Fizz’s two-sensor experiment', detail: 'Compared both whisker inputs', time: 'Tue', icon: BatteryCharging, tone: 'lilac' },
  { title: 'Daisy’s chime idea', detail: 'Sketched a sound-sensor circuit', time: 'Mon', icon: Sparkles, tone: 'peach' },
  { title: 'Pebble’s compass patch', detail: 'Planned a direction-finding circuit', time: 'Sun', icon: CircuitBoard, tone: 'gold' },
  { title: 'Fizz balanced her sensor leads', detail: 'Compared two parallel input paths', time: 'Sat', icon: BatteryCharging, tone: 'lilac' },
  { title: 'Daisy’s first sound test', detail: 'Matched a buzzer with a sound sensor', time: 'Fri', icon: Zap, tone: 'peach' },
  { title: 'A new lab partner arrived', detail: 'Pebble brought a compass patch idea', time: 'Thu', icon: PawPrint, tone: 'mint' },
]

export function ProgressDashboard({ completed, activePlushieName }: { completed: boolean; activePlushieName: string }) {
  const visibleLabs = completed ? labs.map((lab) => ({
    ...lab,
    detail: lab.number === '01' ? '4 of 4 experiments complete' : lab.number === '02' ? 'Newly unlocked · ready to explore' : lab.detail,
    state: lab.number === '01' ? 'complete' : lab.number === '02' ? 'current' : lab.state,
  })) : labs
  const visibleActivity = completed ? [
    { title: `${activePlushieName}’s first spark`, detail: 'Circuit tested · First Spark badge unlocked', time: 'Just now', icon: Sparkles, tone: 'lilac' },
    ...activity.slice(0, 8),
  ] : activity
  return (
    <>
      <div className="stats-heading"><span className="card-kicker">YOUR MAKER SNAPSHOT</span><span className="demo-tag">SAMPLE PROFILE · MORGAN</span></div>
      <section className="stats-strip" aria-label="Your maker stats">
        {stats.map(({ label, value, completedValue, note, completedNote, icon: Icon, tone }) => (
          <article className="stat-card" key={label}>
            <span className={`stat-icon ${tone}`}><Icon size={17} aria-hidden="true" /></span>
            <div className="stat-copy"><span>{label}</span><strong>{completed ? completedValue : value}</strong><small>{completed ? completedNote : note}</small></div>
            <ArrowUpRight className="stat-arrow" size={14} aria-hidden="true" />
          </article>
        ))}
      </section>

      <section className="progress-dashboard" aria-label="Your workshop progress">
        <div className="journey-card">
          <div className="dashboard-heading"><div><span className="card-kicker">YOUR LEARNING PATH</span><h2>Little labs, big discoveries</h2><p>Every new skill gives your plushies another way to shine.</p></div><span className="journey-total"><Sparkles size={13} /> {completed ? '2 of 7' : '1 of 7'}</span></div>
          <div className="lab-list">
            {visibleLabs.map((lab) => (
              <article className={`lab-row ${lab.state}`} key={lab.number}>
                <span className="lab-marker">{lab.state === 'complete' ? <Check size={14} /> : lab.state === 'locked' ? <LockKeyhole size={12} /> : lab.number}</span>
                <div className="lab-copy"><strong>{lab.name}</strong><small>{lab.detail}</small></div>
                {lab.state === 'current' && <span className="now-tag">CURRENT</span>}
                {lab.state === 'complete' && <span className="lab-stars"><Star size={11} fill="currentColor" /> 3</span>}
              </article>
            ))}
          </div>
          <div className="journey-foot"><BookOpen size={14} /><span>{completed ? 'New lab unlocked: sew your first wearable circuit.' : 'Up next: stitch a glowing pathway into Pip’s plush heart.'}</span><ArrowUpRight size={14} /></div>
        </div>

        <div className="crew-card">
          <div className="dashboard-heading"><div><span className="card-kicker">THE PLUSHIE CREW</span><h2>Your little lab partners</h2><p>Each one has a different electrical mystery.</p></div><span className="crew-count">{String(friends.length).padStart(2, '0')} friends</span></div>
          <div className="friend-list">
            {friends.map((friend) => (
              <article className="friend-row" key={friend.name}>
                <div className={`friend-avatar ${friend.tone}`}>
                  <Image src={friend.image} alt="" width={72} height={72} sizes="52px" />
                </div>
                <div className="friend-copy"><strong>{friend.name} <span>{friend.type}</span></strong><small>{friend.name === activePlushieName && completed ? 'Special ability awakened' : friend.mood}</small></div>
                <span className={`friend-status ${friend.image ? 'status-current' : ''}`}>{friend.name === activePlushieName ? completed ? 'Ability active' : 'Lab partner' : friend.progress}</span>
              </article>
            ))}
          </div>
          <div className="crew-note"><span className="crew-note-icon"><Clock3 size={14} /></span><span><strong>Last tinkered</strong> Yesterday, after school</span><span className="crew-note-streak"><Zap size={12} fill="currentColor" /> 3 day streak</span></div>
        </div>
      </section>

      <section className="activity-card" aria-label="Recent workshop activity">
        <div className="activity-heading"><div><span className="card-kicker">THE STORY SO FAR</span><h2>Recent discoveries</h2></div><span className="activity-subtitle">Your last few wins, all in one place</span></div>
        <div className="activity-list">
          {visibleActivity.map(({ title, detail, time, icon: Icon, tone }) => (
            <article className="activity-row" key={title}>
              <span className={`activity-icon ${tone}`}><Icon size={16} aria-hidden="true" /></span>
              <div className="activity-copy"><strong>{title}</strong><small>{detail}</small></div>
              <time>{time}</time>
            </article>
          ))}
        </div>
      </section>
    </>
  )
}
