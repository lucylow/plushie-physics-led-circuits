'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import { Battery, Check, ChevronRight, CircuitBoard, Lightbulb, Minus, RotateCcw, Scissors, Sparkles, Volume2, Zap } from 'lucide-react'
import { GameLoop } from './game-loop'
import { ProgressDashboard } from './progress-dashboard'

type Part = 'battery' | 'thread' | 'led' | 'resistor' | 'resistor-left' | 'whisker-left' | 'resistor-right' | 'whisker-right' | 'switch' | 'motor' | 'pressure-sensor' | 'buzzer' | 'water-sensor' | 'temperature-sensor' | 'sound-sensor' | 'compass-sensor'
type PlushieId = 'pip' | 'miso' | 'orbit' | 'nori' | 'button' | 'fizz' | 'daisy' | 'pebble'
type CircuitTopology = 'single' | 'parallel'

type PartDefinition = { label: string; detail: string; icon: typeof Battery; color: string }
type MockInput = { key: string; label: string; initialValue: number; min: number; max: number; step: number; unit: string }
type MockValidation =
  | { type: 'minimum'; key: string; target: number; failedHint: string; passHint: string }
  | { type: 'max-difference'; firstKey: string; secondKey: string; tolerance: number; failedHint: string; passHint: string }
type CircuitIssue = 'current' | 'sensor' | 'switch' | 'both'

type PlushieProfile = {
  name: string
  species: string
  image: string
  heading: string
  labName: string
  labEyebrow: string
  challengeNumber: string
  problem: string
  mission: string
  ability: string
  circuitLabel: string
  lightComponent: string
  lightDetail: string
  outputPart: Part
  outputLabel: string
  voltageDropV: number
  loadResistanceOhms: number
  minimumCurrentMa: number
  componentSummary: string
  seriesResistanceOhms?: number
  difficulty?: string
  mockData?: { label: string; value: string; inputKey?: string; unit?: string }[]
  mockInputs?: MockInput[]
  mockValidation?: MockValidation
  caption: string
  topology: CircuitTopology
  parts: Part[]
}

type CircuitActivity = {
  id: number
  partnerName: string
  result: 'passed' | 'retry'
  currentMa: number
  threadLength: number
  issue?: CircuitIssue
}

const plushies: Record<PlushieId, PlushieProfile> = {
  pip: {
    name: 'Pip', species: 'Lavender bunny', image: '/plushie-hero.png',
    heading: 'Give Pip a little spark', labName: 'Conductivity Garden', labEyebrow: 'LAB 01 • ELECTRICITY BASICS', challengeNumber: '01',
    problem: 'Pip’s heart light has gone dim. Can you help it shine?', mission: 'Make Pip’s heart shine!', ability: 'Heartlight glow',
    circuitLabel: 'PIP’S HEART CIRCUIT', lightComponent: 'Heart LED', lightDetail: 'Light up Pip’s heart', outputPart: 'led', outputLabel: 'heart LED',
    voltageDropV: 2, loadResistanceOhms: 68, minimumCurrentMa: 12.5, componentSummary: 'a battery, conductive thread, and one LED',
    difficulty: 'CLOSED-LOOP BASICS', mockData: [{ label: 'Coin cell', value: '3.0 V' }, { label: 'Heart LED drop', value: '2.0 V' }, { label: 'Thread at 30 cm', value: '18 Ω' }, { label: 'Target current', value: '≥ 12.5 mA' }],
    caption: 'A very brave little bunny', topology: 'single', parts: ['battery', 'thread', 'led'],
  },
  miso: {
    name: 'Miso', species: 'Peachy cat', image: '/plushie-miso.png',
    heading: 'Give Miso a moonlit spark', labName: 'Circuit Sewing Studio', labEyebrow: 'LAB 02 • PARALLEL CIRCUITS', challengeNumber: '02',
    problem: 'Miso’s moonlight whiskers have gone dark. Can you bring back her night-glow?', mission: 'Wake Miso’s moonlight!', ability: 'Moonlight whiskers',
    circuitLabel: 'MISO’S MOONLIGHT CIRCUIT', lightComponent: 'Whisker LEDs', lightDetail: 'Two parallel light branches', outputPart: 'whisker-left', outputLabel: 'whisker LEDs',
    voltageDropV: 2, loadResistanceOhms: 150, minimumCurrentMa: 6.2, componentSummary: 'two whisker LEDs and a 150 Ω resistor for each parallel branch',
    difficulty: 'PARALLEL CIRCUITS', mockData: [{ label: 'Coin cell', value: '3.0 V' }, { label: 'LED drop per branch', value: '2.0 V' }, { label: 'Branch resistor', value: '150 Ω' }, { label: 'Target current / branch', value: '≥ 6.2 mA' }],
    caption: 'A curious kitten who loves the stars', topology: 'parallel', parts: ['battery', 'thread', 'resistor-left', 'whisker-left', 'resistor-right', 'whisker-right'],
  },
  orbit: {
    name: 'Orbit', species: 'Sleepy moon bear', image: '/plushie-orbit.png',
    heading: 'Wake Orbit with a gentle rumble', labName: 'Electromagnetic Garage', labEyebrow: 'LAB 04 • MOTION CIRCUITS', challengeNumber: '03',
    problem: 'Orbit’s sleepy paws need a tiny vibration to wake up.', mission: 'Build Orbit a vibration circuit!', ability: 'Cozy rumble',
    circuitLabel: 'ORBIT’S VIBRATION CIRCUIT', lightComponent: 'Vibration motor', lightDetail: 'Give Orbit a gentle buzz', outputPart: 'motor', outputLabel: 'vibration motor',
    voltageDropV: 0, loadResistanceOhms: 60, minimumCurrentMa: 18.2, componentSummary: 'a battery, switch, series resistor, and vibration motor',
    seriesResistanceOhms: 100, difficulty: 'ADVANCED CIRCUIT', mockData: [{ label: 'Battery voltage', value: '3.0 V' }, { label: 'Series resistor', value: '100 Ω' }, { label: 'Motor current target', value: '≥ 18.2 mA' }],
    caption: 'A sleepy bear with big dreams', topology: 'single', parts: ['battery', 'thread', 'switch', 'resistor', 'motor'],
  },
  nori: {
    name: 'Nori', species: 'Mint sea turtle', image: '/plushie-nori.png',
    heading: 'Help Nori sense a squeeze', labName: 'Sensor Pet Sanctuary', labEyebrow: 'LAB 05 • PRESSURE SENSORS', challengeNumber: '04',
    problem: 'Nori’s shell sensor cannot tell when someone gives a gentle squeeze.', mission: 'Wake Nori’s shell sensor!', ability: 'Shell glow map',
    circuitLabel: 'NORI’S PRESSURE SENSOR', lightComponent: 'Shell indicator LED', lightDetail: 'Show a gentle squeeze', outputPart: 'led', outputLabel: 'shell indicator LED',
    voltageDropV: 1.5, loadResistanceOhms: 80, minimumCurrentMa: 8.1, componentSummary: 'a battery, pressure sensor, 100 Ω resistor, and indicator LED',
    seriesResistanceOhms: 100, difficulty: 'SENSOR CALIBRATION', mockData: [{ label: 'Squeezed sensor output', value: '0.65 V', inputKey: 'pressure', unit: 'V' }, { label: 'LED forward voltage', value: '1.5 V' }, { label: 'Series resistor', value: '100 Ω' }, { label: 'Target current', value: '≥ 8.1 mA' }],
    mockInputs: [{ key: 'pressure', label: 'Pressure sensor output', initialValue: 0.65, min: 0, max: 1, step: 0.05, unit: 'V' }],
    mockValidation: { type: 'minimum', key: 'pressure', target: 0.6, failedHint: 'Raise the pressure signal to at least 0.60 V.', passHint: 'Pressure signal is within range.' },
    caption: 'A gentle turtle with a clever shell', topology: 'single', parts: ['battery', 'thread', 'pressure-sensor', 'resistor', 'led'],
  },
  button: {
    name: 'Button', species: 'Sunny fox', image: '/plushie-button.png',
    heading: 'Build Button a tiny doorbell', labName: 'Circuit Sewing Studio', labEyebrow: 'LAB 02 • SWITCHES & BUZZERS', challengeNumber: '05',
    problem: 'Button’s welcome bell stays silent when a visitor presses the paw switch.', mission: 'Make Button’s doorbell ring!', ability: 'Friendly chime',
    circuitLabel: 'BUTTON’S DOORBELL CIRCUIT', lightComponent: 'Mini buzzer', lightDetail: 'Ring on a button press', outputPart: 'buzzer', outputLabel: 'mini buzzer',
    voltageDropV: 0.5, loadResistanceOhms: 120, minimumCurrentMa: 9, componentSummary: 'a battery, paw switch, 150 Ω resistor, and mini buzzer',
    seriesResistanceOhms: 150, difficulty: 'SWITCH & CURRENT LIMITING', mockData: [{ label: 'Closed switch reference', value: '0.1 Ω' }, { label: 'Series resistor', value: '150 Ω' }, { label: 'Buzzer current target', value: '≥ 9 mA' }],
    caption: 'A sunny fox who loves visitors', topology: 'single', parts: ['battery', 'thread', 'switch', 'resistor', 'buzzer'],
  },
  fizz: {
    name: 'Fizz', species: 'Sky-blue axolotl', image: '/plushie-fizz.png',
    heading: 'Balance Fizz’s sensor leads', labName: 'Microcontroller Magic Room', labEyebrow: 'LAB 06 • SENSOR INPUTS', challengeNumber: '06',
    problem: 'Fizz’s gill sensors disagree about the water temperature.', mission: 'Balance Fizz’s sensor circuit!', ability: 'Gills glow in sync',
    circuitLabel: 'FIZZ’S SENSOR CIRCUIT', lightComponent: 'Sensor status LED', lightDetail: 'Show balanced sensor readings', outputPart: 'led', outputLabel: 'sensor status LED',
    voltageDropV: 2, loadResistanceOhms: 68, minimumCurrentMa: 3.4, componentSummary: 'a battery, water sensor, temperature sensor, 220 Ω resistor, and status LED',
    seriesResistanceOhms: 220, difficulty: 'TIGHT SENSOR BALANCE', mockData: [{ label: 'Water sensor', value: '22 °C', inputKey: 'waterTemp', unit: '°C' }, { label: 'Temperature sensor', value: '26 °C', inputKey: 'gillTemp', unit: '°C' }, { label: 'Series resistor', value: '220 Ω' }, { label: 'Status LED target', value: '≥ 3.4 mA' }, { label: 'Sensor difference target', value: '≤ 1 °C' }],
    mockInputs: [{ key: 'waterTemp', label: 'Water sensor', initialValue: 22, min: 0, max: 40, step: 1, unit: '°C' }, { key: 'gillTemp', label: 'Gill sensor', initialValue: 26, min: 0, max: 40, step: 1, unit: '°C' }],
    mockValidation: { type: 'max-difference', firstKey: 'waterTemp', secondKey: 'gillTemp', tolerance: 1, failedHint: 'Bring the two temperature readings within 1 °C.', passHint: 'The two temperature readings are balanced within 1 °C.' },
    caption: 'A bubbly axolotl who notices everything', topology: 'single', parts: ['battery', 'thread', 'water-sensor', 'temperature-sensor', 'resistor', 'led'],
  },
  daisy: {
    name: 'Daisy', species: 'Blush lamb', image: '/plushie-daisy.png',
    heading: 'Help Daisy hear a clap', labName: 'Microcontroller Magic Room', labEyebrow: 'LAB 06 • SOUND CIRCUITS', challengeNumber: '07',
    problem: 'Daisy’s sound sensor misses a clap, so her welcome chime never rings.', mission: 'Give Daisy a clap-activated chime!', ability: 'Sunshine chime',
    circuitLabel: 'DAISY’S SOUND SENSOR', lightComponent: 'Mini buzzer', lightDetail: 'Ring when a clap is heard', outputPart: 'buzzer', outputLabel: 'mini buzzer',
    voltageDropV: 0.5, loadResistanceOhms: 120, minimumCurrentMa: 7.25, componentSummary: 'a battery, sound sensor, 220 Ω resistor, and mini buzzer',
    seriesResistanceOhms: 220, difficulty: 'HIGHER SOUND THRESHOLD', mockData: [{ label: 'Clap sensor peak', value: '0.42 V', inputKey: 'clapPeak', unit: 'V' }, { label: 'Trigger threshold', value: '0.65 V' }, { label: 'Series resistor', value: '220 Ω' }, { label: 'Buzzer current target', value: '≥ 7.25 mA' }],
    mockInputs: [{ key: 'clapPeak', label: 'Clap sensor peak', initialValue: 0.42, min: 0, max: 1, step: 0.01, unit: 'V' }],
    mockValidation: { type: 'minimum', key: 'clapPeak', target: 0.65, failedHint: 'Raise the clap peak to at least 0.65 V.', passHint: 'Clap is above the 0.65 V trigger threshold.' },
    caption: 'A soft lamb who loves a happy hello', topology: 'single', parts: ['battery', 'thread', 'sound-sensor', 'resistor', 'buzzer'],
  },
  pebble: {
    name: 'Pebble', species: 'Lilac hedgehog', image: '/plushie-pebble.png',
    heading: 'Help Pebble find north', labName: 'Advanced Plushie Research Center', labEyebrow: 'LAB 07 • COMPASS CIRCUITS', challengeNumber: '08',
    problem: 'Pebble’s compass patch cannot find north or light its tiny guide LED.', mission: 'Calibrate Pebble’s compass patch!', ability: 'Northstar glow',
    circuitLabel: 'PEBBLE’S COMPASS PATCH', lightComponent: 'Compass indicator LED', lightDetail: 'Point the way north', outputPart: 'led', outputLabel: 'compass indicator LED',
    voltageDropV: 1.2, loadResistanceOhms: 80, minimumCurrentMa: 6.8, componentSummary: 'a battery, compass sensor, 180 Ω resistor, and indicator LED',
    seriesResistanceOhms: 180, difficulty: 'PRECISION COMPASS CALIBRATION', mockData: [{ label: 'Compass signal', value: '0.41 V', inputKey: 'compassSignal', unit: 'V' }, { label: 'North reference', value: '0.75 V' }, { label: 'Series resistor', value: '180 Ω' }, { label: 'LED current target', value: '≥ 6.8 mA' }],
    mockInputs: [{ key: 'compassSignal', label: 'Compass signal', initialValue: 0.41, min: 0, max: 1, step: 0.01, unit: 'V' }],
    mockValidation: { type: 'minimum', key: 'compassSignal', target: 0.75, failedHint: 'Calibrate the compass signal to at least 0.75 V.', passHint: 'Compass signal is aligned to the 0.75 V north reference.' },
    caption: 'A thoughtful hedgehog with a sense of direction', topology: 'single', parts: ['battery', 'thread', 'compass-sensor', 'resistor', 'led'],
  },
}

const partCatalog: Record<Part, PartDefinition> = {
  battery: { label: 'Coin cell', detail: '3V power source', icon: Battery, color: 'lilac' },
  thread: { label: 'Conductive thread', detail: 'Connect the circuit', icon: Scissors, color: 'peach' },
  led: { label: 'LED module', detail: 'Choose a light source', icon: Lightbulb, color: 'mint' },
  resistor: { label: 'Series resistor', detail: 'Limit current · value in bench data', icon: CircuitBoard, color: 'peach' },
  'resistor-left': { label: 'Left branch resistor', detail: '150 Ω current limiter', icon: CircuitBoard, color: 'peach' },
  'whisker-left': { label: 'Left whisker LED', detail: 'First parallel branch', icon: Lightbulb, color: 'mint' },
  'resistor-right': { label: 'Right branch resistor', detail: '150 Ω current limiter', icon: CircuitBoard, color: 'peach' },
  'whisker-right': { label: 'Right whisker LED', detail: 'Second parallel branch', icon: Lightbulb, color: 'mint' },
  switch: { label: 'Paw switch', detail: 'Close the circuit', icon: CircuitBoard, color: 'lilac' },
  motor: { label: 'Vibration motor', detail: 'Create a gentle rumble', icon: RotateCcw, color: 'peach' },
  'pressure-sensor': { label: 'Pressure sensor', detail: 'Detect a gentle squeeze', icon: CircuitBoard, color: 'mint' },
  buzzer: { label: 'Mini buzzer', detail: 'Play a soft chime', icon: Volume2, color: 'peach' },
  'water-sensor': { label: 'Water sensor', detail: 'Read moisture level', icon: CircuitBoard, color: 'mint' },
  'temperature-sensor': { label: 'Temperature sensor', detail: 'Read water temperature', icon: CircuitBoard, color: 'lilac' },
  'sound-sensor': { label: 'Sound sensor', detail: 'Listen for a clap', icon: Volume2, color: 'peach' },
  'compass-sensor': { label: 'Compass sensor', detail: 'Find magnetic north', icon: CircuitBoard, color: 'mint' },
}

export function GameBoard() {
  const [activePlushieId, setActivePlushieId] = useState<PlushieId>('pip')
  const plushieOrder: PlushieId[] = ['pip', 'miso', 'orbit', 'nori', 'button', 'fizz', 'daisy', 'pebble']
  const [activeSection, setActiveSection] = useState<'lab' | 'closet' | 'badges'>('lab')
  const [mockValues, setMockValues] = useState<Record<string, number>>({})
  const [switchClosed, setSwitchClosed] = useState(false)
  const [completedPlushieIds, setCompletedPlushieIds] = useState<PlushieId[]>([])
  const [circuitTests, setCircuitTests] = useState(0)
  const [activity, setActivity] = useState<CircuitActivity[]>([])
  const activityId = useRef(0)
  const [placed, setPlaced] = useState<Part[]>([])
  const [threadLength, setThreadLength] = useState(30)
  const activePlushie = plushies[activePlushieId]
  const parts = activePlushie.parts.map((partId) => ({ id: partId, ...partCatalog[partId] }))
  const hasAllParts = parts.every((part) => placed.includes(part.id))
  const [testResult, setTestResult] = useState<'dim' | 'success' | null>(null)
  const [lastFault, setLastFault] = useState<{ threadLength: number; currentMa: number; issue: CircuitIssue } | null>(null)
  const threadResistance = threadLength * 0.6
  const addedSeriesResistance = placed.includes('resistor') ? activePlushie.seriesResistanceOhms ?? 0 : 0
  const circuitResistance = activePlushie.loadResistanceOhms + threadResistance + addedSeriesResistance
  const switchOpen = activePlushie.parts.includes('switch') && !switchClosed
  const singleLoadCurrentMa = switchOpen ? 0 : Number((((3 - activePlushie.voltageDropV) / circuitResistance) * 1000).toFixed(1))
  const branchCurrentMa = singleLoadCurrentMa
  const parallelTotalCurrentMa = Number((branchCurrentMa * 2).toFixed(1))
  const simulatedCurrentMa = activePlushie.topology === 'parallel' ? branchCurrentMa : singleLoadCurrentMa
  const circuitThresholdMa = activePlushie.minimumCurrentMa
  const mockValidation = activePlushie.mockValidation
  const mockValidationPasses = !mockValidation || (mockValidation.type === 'minimum'
    ? getMockInputValue(mockValidation.key) >= mockValidation.target
    : Math.abs(getMockInputValue(mockValidation.firstKey) - getMockInputValue(mockValidation.secondKey)) <= mockValidation.tolerance)
  const electricalTargetMet = hasAllParts && !switchOpen && simulatedCurrentMa >= circuitThresholdMa
  const currentMeterStatus = !hasAllParts ? 'Add required parts' : switchOpen ? 'Switch open · no current' : electricalTargetMet ? 'Electrical target met' : 'Below target · shorten stitch'
  const OutputIcon = partCatalog[activePlushie.outputPart].icon
  const completed = hasAllParts && testResult === 'success'

  function togglePart(part: Part) {
    const isRemoving = placed.includes(part)
    setPlaced((current) => isRemoving ? current.filter((placedPart) => placedPart !== part) : [...current, part])
    if (part === 'switch' && isRemoving) setSwitchClosed(false)
    setTestResult(null)
    setLastFault(null)
  }

  function getMockInputValue(key: string) {
    const input = activePlushie.mockInputs?.find((mockInput) => mockInput.key === key)
    return mockValues[`${activePlushieId}:${key}`] ?? input?.initialValue ?? 0
  }

  function updateMockInput(key: string, value: number) {
    setMockValues((current) => ({ ...current, [`${activePlushieId}:${key}`]: value }))
    setTestResult(null)
    setLastFault(null)
  }

  function toggleSwitch() {
    setSwitchClosed((current) => !current)
    setTestResult(null)
    setLastFault(null)
  }

  function reset() {
    setPlaced([])
    setThreadLength(30)
    setSwitchClosed(false)
    setTestResult(null)
    setLastFault(null)
  }

  function selectPlushie(plushieId: PlushieId) {
    setActivePlushieId(plushieId)
    setActiveSection('lab')
    setPlaced([])
    setThreadLength(30)
    setSwitchClosed(false)
    setTestResult(null)
    setLastFault(null)
  }

  function testCircuit() {
    if (!hasAllParts) return
    const currentPasses = !switchOpen && simulatedCurrentMa >= circuitThresholdMa
    const result: CircuitActivity['result'] = currentPasses && mockValidationPasses ? 'passed' : 'retry'
    const issue: CircuitIssue | undefined = result === 'passed' ? undefined : switchOpen ? 'switch' : !currentPasses && !mockValidationPasses ? 'both' : !currentPasses ? 'current' : 'sensor'
    activityId.current += 1
    setCircuitTests((current) => current + 1)
    setActivity((current) => [{ id: activityId.current, partnerName: activePlushie.name, result, currentMa: simulatedCurrentMa, threadLength, issue }, ...current].slice(0, 10))
    if (result === 'passed') {
      setTestResult('success')
      setLastFault(null)
      setCompletedPlushieIds((current) => current.includes(activePlushieId) ? current : [...current, activePlushieId])
    } else {
      setTestResult('dim')
      setLastFault({ threadLength, currentMa: simulatedCurrentMa, issue: issue ?? 'current' })
    }
  }

  function selectPartnerFromDashboard(partnerId: string) {
    if (!plushieOrder.includes(partnerId as PlushieId)) return
    selectPlushie(partnerId as PlushieId)
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    document.getElementById('circuit-studio')?.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth' })
  }

  function partLabel(part: (typeof parts)[number]) {
    return part.id === 'led' ? activePlushie.lightComponent : part.label
  }

  function partDetail(part: (typeof parts)[number]) {
    return part.id === 'led' ? activePlushie.lightDetail : part.detail
  }

  return (
    <main className="lab-shell">
      <aside className="sidebar">
        <a className="brand" href="#circuit-studio" aria-label="Plushie Physics Lab home"><span className="brand-mark"><Zap size={19} fill="currentColor" /></span><span>little sparks<span className="brand-sub">PLUSHIE PHYSICS LAB</span></span></a>
        <div className="side-label">YOUR WORKSHOP</div>
        <a className={`nav-item ${activeSection === 'lab' ? 'active' : ''}`} href="#circuit-studio" onClick={() => setActiveSection('lab')}><CircuitBoard size={18} /> Circuit studio <span className="nav-dot" /></a>
        <a className={`nav-item ${activeSection === 'closet' ? 'active' : ''}`} href="#plushie-closet" onClick={() => setActiveSection('closet')}><Sparkles size={18} /> Plushie closet</a>
        <a className={`nav-item ${activeSection === 'badges' ? 'active' : ''}`} href="#badge-progress" onClick={() => setActiveSection('badges')}><Check size={18} /> My badges <span className="badge-count">{completedPlushieIds.length}</span></a>
        <div className="side-card"><div className="side-card-icon"><Sparkles size={16} /></div><strong>Little steps,<br />big sparks.</strong><p>Every experiment makes you a better engineer.</p><div className="spark-progress"><span style={{ width: `${(completedPlushieIds.length / plushieOrder.length) * 100}%` }} /></div><small>{completedPlushieIds.length} of {plushieOrder.length} circuits complete</small></div>
        <div className="profile"><div className="avatar">L</div><div><strong>Lab learner</strong><small>Current session</small></div></div>
      </aside>

      <section className="workspace" id="circuit-studio">
        <header className="topbar"><div className="crumb">Little Sparks Institute <ChevronRight size={14} /> <strong>{activePlushie.labName}</strong></div><div className="top-actions"><span className="streak"><Sparkles size={12} aria-hidden="true" /> Session · {completedPlushieIds.length}/{plushieOrder.length} complete</span><div className="top-avatar">L</div></div></header>
        <nav className="mobile-nav" aria-label="Workshop sections"><a className={activeSection === 'lab' ? 'active' : ''} href="#circuit-studio" onClick={() => setActiveSection('lab')}><CircuitBoard size={15} aria-hidden="true" /><span>Studio</span></a><a className={activeSection === 'closet' ? 'active' : ''} href="#plushie-closet" onClick={() => setActiveSection('closet')}><Sparkles size={15} aria-hidden="true" /><span>Plushie closet</span></a><a className={activeSection === 'badges' ? 'active' : ''} href="#badge-progress" onClick={() => setActiveSection('badges')}><Check size={15} aria-hidden="true" /><span>Badges <small>{completedPlushieIds.length}</small></span></a></nav>
        <div className="content">
          <div className="level-row"><div><div className="eyebrow">{activePlushie.labEyebrow}</div><h1>{activePlushie.heading}</h1><p className="intro">{activePlushie.problem}</p></div><div className="level-pill"><Sparkles className="level-icon" size={18} aria-hidden="true" /><span><small>YOUR PROGRESS</small><strong>Level {Math.min(completedPlushieIds.length + 1, plushieOrder.length)} <i>of {plushieOrder.length}</i></strong></span><span className="progress-ring">{completedPlushieIds.length}</span></div></div>
          <div className="plushie-picker"><span className="picker-kicker">CHOOSE YOUR LAB PARTNER</span><div className="plushie-options" role="group" aria-label="Choose a plushie">{plushieOrder.map((plushieId) => { const plushie = plushies[plushieId]; return <button key={plushieId} type="button" className={`plushie-option ${activePlushieId === plushieId ? 'selected' : ''}`} aria-pressed={activePlushieId === plushieId} onClick={() => selectPlushie(plushieId)}><Image src={plushie.image} alt="" width={44} height={44} sizes="44px" /><span><strong>{plushie.name}</strong><small>{plushie.species}</small></span>{activePlushieId === plushieId && <Check size={15} aria-hidden="true" />}</button> })}</div></div>
          <div className="game-loop-summary" aria-label="Game loop: adopt, discover, build, stitch, test, debug, improve, activate, and unlock"><span>ADOPT</span><ChevronRight size={12} /><span>DISCOVER</span><ChevronRight size={12} /><span>BUILD & SEW</span><ChevronRight size={12} /><span>TEST, DEBUG & TUNE</span><ChevronRight size={12} /><span>SPARK & UNLOCK</span></div>
          <div className="game-grid">
            <section className="play-card" aria-label="Circuit building game">
              <div className="play-card-head"><div><span className="live-dot" /> <strong>THE WORKBENCH</strong></div><button onClick={reset} className="reset-button"><RotateCcw size={14} /> Start over</button></div>
              <div className={`scene scene-${activePlushieId} ${completed ? 'scene-success' : testResult === 'dim' ? 'scene-dim' : ''}`}>
                <div className="scene-stamp">EXPERIMENT {activePlushie.challengeNumber} <Sparkles size={9} aria-hidden="true" /></div>
                {completed && <div className="celebration" aria-hidden="true"><Sparkles className="celebration-one" size={16} /><Sparkles className="celebration-two" size={12} /><Sparkles className="celebration-three" size={18} /><Sparkles className="celebration-four" size={13} /><Sparkles className="celebration-five" size={15} /></div>}
                <div className="scene-decor decor-one"><Sparkles size={17} aria-hidden="true" /></div><div className="scene-decor decor-two"><Sparkles size={14} aria-hidden="true" /></div><div className="scene-decor decor-three">· · ·</div>
                <div className="plushie-wrap"><div className={`heart-glow ${completed ? 'glowing' : ''} ${activePlushieId === 'miso' ? 'moon-glow' : ''}`} /><Image className="plushie" src={activePlushie.image} alt={`${activePlushie.name}, a ${activePlushie.species} plushie`} width={310} height={310} priority /><div className={`heart-light ${completed ? 'on' : testResult === 'dim' ? 'dim' : ''} ${activePlushie.topology === 'parallel' ? 'moonlight' : ''}`}>{activePlushieId === 'pip' ? completed ? '♥' : '♡' : <OutputIcon size={20} aria-hidden="true" />}</div></div>
                <div className="pip-caption"><strong>{completed ? `${activePlushie.name} is glowing!` : `Meet ${activePlushie.name}`}</strong><span>{completed ? 'You did it, engineer!' : activePlushie.caption}</span></div>
                {activePlushie.topology === 'parallel' ? (
                  <div className={`parallel-board ${testResult === 'dim' ? 'parallel-dim' : completed ? 'parallel-success' : ''}`} aria-label="Two parallel LED branches, each protected by a resistor">
                    <div className={`parallel-source ${placed.includes('battery') ? 'active' : ''}`}><Battery size={15} /><span>3V</span></div>
                    <span className={`parallel-feed ${placed.includes('thread') ? 'connected' : ''}`} />
                    <div className="parallel-branches">
                      <span className="parallel-bus left" /><span className="parallel-bus right" />
                      {([{ id: 'left', resistor: 'resistor-left' as Part, led: 'whisker-left' as Part }, { id: 'right', resistor: 'resistor-right' as Part, led: 'whisker-right' as Part }]).map((branch) => (
                        <div className="parallel-branch" key={branch.id}>
                          <span className={`parallel-wire ${placed.includes('thread') ? 'connected' : ''}`} />
                          <span className={`parallel-resistor ${placed.includes(branch.resistor) ? 'active' : ''}`}>150Ω</span>
                          <span className={`parallel-wire ${placed.includes('thread') ? 'connected' : ''}`} />
                          <span className={`parallel-led ${placed.includes(branch.led) ? 'active' : ''}`}><Lightbulb size={12} aria-hidden="true" /></span>
                          <span className="parallel-branch-label">{branch.id === 'left' ? 'L' : 'R'}</span>
                        </div>
                      ))}
                    </div>
                    <span className={`parallel-feed return ${placed.includes('thread') ? 'connected' : ''}`} />
                    <div className="parallel-return"><span>↩</span></div>
                    <div className="parallel-board-label">MISO’S PARALLEL WHISKERS</div>
                  </div>
                ) : (
                  <div className="circuit-board">
                    <div className={`circuit-node node-battery ${placed.includes('battery') ? 'filled' : ''}`}><Battery size={17} /><span>+</span></div>
                    <div className={`circuit-wire wire-one ${placed.includes('thread') ? `connected ${threadLength > 15 ? 'long' : 'short'}` : ''}`} />
                    {activePlushie.parts.filter((partId) => !['battery', 'thread', activePlushie.outputPart].includes(partId)).map((partId) => { const PartIcon = partCatalog[partId].icon; return <div className={`circuit-intermediate circuit-intermediate-${partId}`} key={partId}><div className={`circuit-node circuit-node-small ${placed.includes(partId) ? 'filled' : ''}`} aria-label={partCatalog[partId].label}><PartIcon size={13} aria-hidden="true" /></div><div className={`circuit-wire ${placed.includes('thread') ? 'connected' : ''}`} /></div> })}
                    <div className={`circuit-node node-led node-output ${placed.includes(activePlushie.outputPart) ? 'filled' : ''}`}><OutputIcon size={17} aria-hidden="true" /></div>
                    <div className={`circuit-wire wire-two ${placed.includes('thread') ? `connected ${threadLength > 15 ? 'long' : 'short'}` : ''}`} />
                    <div className="circuit-node node-return"><span>↩</span></div>
                    <div className="board-label">{activePlushie.circuitLabel}</div>
                  </div>
                )}
              </div>
              <div className="workbench-foot"><div className="step-dots"><span className="done" /><span className={placed.length > 0 ? 'done' : ''} /><span className={hasAllParts ? 'done' : ''} /><span className={completed ? 'done' : ''} /></div><p>{completed ? `Circuit complete — ${activePlushie.name} feels the love!` : `Build a closed loop to complete ${activePlushie.name}’s circuit.`}</p><Sparkles className="foot-spark" size={15} aria-hidden="true" /></div>
            </section>

            <aside className="mission-column">
              <section className="mission-card"><div className="card-kicker">TODAY&apos;S CHALLENGE <span>{activePlushie.challengeNumber} / 08</span></div><h2>{activePlushie.mission}</h2><p>{activePlushie.topology === 'parallel' ? 'Build two parallel whisker branches. Each branch needs its own resistor and LED; both branches receive the battery’s full voltage.' : `Build ${activePlushie.componentSummary} into a complete path. Test it, then shorten the thread to reduce resistance.`}</p>{activePlushie.mockData && <section className="mock-data-card" aria-label={`${activePlushie.name} mock bench readings`}><div className="mock-data-heading"><span className="card-kicker">MOCK BENCH DATA</span><span className="mock-data-difficulty">{activePlushie.difficulty}</span></div><div className="mock-data-grid">{activePlushie.mockData.map(({ label, value, inputKey, unit }) => { const readingValue = inputKey ? `${getMockInputValue(inputKey)} ${unit ?? ''}`.trim() : value; return <div className="mock-reading" key={label}><span>{label}</span><strong>{readingValue}</strong></div> })}{activePlushie.parts.includes('switch') && <div className={`mock-reading mock-reading-live ${switchClosed ? 'mock-reading-pass' : 'mock-reading-low'}`}><span>Switch state</span><strong>{switchClosed ? 'Closed · 0.1 Ω' : 'Open · 0 mA'}</strong></div>}<div className={`mock-reading mock-reading-live ${electricalTargetMet ? 'mock-reading-pass' : hasAllParts ? 'mock-reading-low' : ''}`}><span>{activePlushie.topology === 'parallel' ? 'Live current / branch' : 'Live load current'}</span><strong>{activePlushie.topology === 'parallel' ? `${simulatedCurrentMa} mA · ${parallelTotalCurrentMa} mA total` : `${simulatedCurrentMa} mA`}</strong><small>{currentMeterStatus}</small></div><div className="mock-reading mock-reading-live"><span>Stitch resistance</span><strong>{threadResistance.toFixed(1)} Ω</strong><small>at {threadLength} cm</small></div>{activePlushie.mockInputs?.map((input) => { const value = getMockInputValue(input.key); return <label className="mock-input-control" key={input.key}><span><span>{input.label}</span><strong>{Number(value.toFixed(input.step < 1 ? 2 : 0))} {input.unit}</strong></span><input type="range" min={input.min} max={input.max} step={input.step} value={value} aria-label={input.label} onChange={(event) => updateMockInput(input.key, Number(event.target.value))} /></label> })}{mockValidation && <div className={`mock-reading mock-reading-live ${mockValidationPasses ? 'mock-reading-pass' : 'mock-reading-low'}`}><span>Sensor check</span><strong>{mockValidationPasses ? 'In range' : 'Needs adjustment'}</strong><small>{mockValidationPasses ? mockValidation.passHint : mockValidation.failedHint}</small></div>}</div></section>}<div className="mission-checklist">{parts.map((part) => <div className={`check-row ${placed.includes(part.id) ? 'checked' : ''}`} key={part.id}><span className="check-box">{placed.includes(part.id) && <Check size={12} />}</span><span>{partLabel(part)}</span>{placed.includes(part.id) && <small>ADDED</small>}</div>)}</div><button className={`test-button ${hasAllParts ? 'ready' : ''}`} onClick={testCircuit} disabled={!hasAllParts}>{completed ? <><Check size={17} /> Circuit complete!</> : <><Zap size={17} fill="currentColor" /> {lastFault ? 'Retest design' : 'Test my circuit'}</>}<span>↗</span></button>{testResult === 'dim' && <p className="feedback" role="status" aria-live="polite">{lastFault?.issue === 'sensor' ? mockValidation?.failedHint ?? 'Adjust the mock sensor reading and retest.' : lastFault?.issue === 'switch' ? 'Close the inline switch to let current flow.' : lastFault?.issue === 'both' ? `${mockValidation?.failedHint ?? 'Adjust the sensor reading.'} Shorten the stitch to raise current.` : activePlushie.topology === 'parallel' ? `Each whisker branch is only ${simulatedCurrentMa} mA. The ${threadLength} cm thread in each branch adds resistance—shorten both stitches and retest.` : `${activePlushie.name}’s ${activePlushie.outputLabel} is underpowered at ${simulatedCurrentMa} mA. The ${threadLength} cm thread adds resistance—shorten the stitch and retest.`}</p>}{completed && <p className="test-success" role="status" aria-live="polite">{activePlushie.topology === 'parallel' ? `Both whiskers glow at ${branchCurrentMa} mA each (${parallelTotalCurrentMa} mA total). Parallel branches each get full battery voltage.` : `${activePlushie.name} activated ${activePlushie.ability} at ${simulatedCurrentMa} mA.${mockValidation ? ` ${mockValidation.passHint}` : ''}`}</p>}</section>
              <section className="parts-card"><div className="parts-heading"><div><span className="card-kicker">YOUR TOOLKIT</span><h3>Pick a component</h3></div><span className="parts-count">{placed.length}/{parts.length}</span></div>{parts.map((part) => { const Icon = part.icon; const isPlaced = placed.includes(part.id); return <button key={part.id} type="button" className={`part-row ${isPlaced ? 'part-added' : ''}`} onClick={() => togglePart(part.id)} aria-pressed={isPlaced} aria-label={`${isPlaced ? 'Remove' : 'Add'} ${partLabel(part)}`}><span className={`part-icon ${part.color}`}><Icon size={18} aria-hidden="true" /></span><span className="part-copy"><strong>{partLabel(part)}</strong><small>{partDetail(part)}</small></span><span className="add-part">{isPlaced ? <Minus size={16} aria-hidden="true" /> : '+'}</span></button> })}{placed.includes('switch') && <div className="switch-control"><div className="thread-control-heading"><span>Inline switch</span><strong>{switchClosed ? 'CLOSED' : 'OPEN'}</strong></div><button type="button" aria-pressed={switchClosed} onClick={toggleSwitch}>{switchClosed ? 'Open switch' : 'Close switch'}</button><small>An open switch stops current.</small></div>}{placed.includes('thread') && <div className="thread-control"><div className="thread-control-heading"><label htmlFor="thread-length">{activePlushie.topology === 'parallel' ? 'Thread length per branch' : 'Conductive thread length'}</label><strong>{threadLength} cm</strong></div><input id="thread-length" aria-label="Conductive thread length in centimeters" aria-valuetext={`${threadLength} centimeters`} type="range" min={5} max={30} step={5} value={threadLength} onChange={(event) => { setThreadLength(Number(event.target.value)); setTestResult(null) }} /><div className="thread-range-labels"><span>Short · brighter</span><span>Long · dimmer</span></div><small>Longer stitches add resistance.</small></div>}<div className="toolkit-tip"><Sparkles size={11} aria-hidden="true" /> Tap an added part to remove it, or tap a new part to add it</div></section>
            </aside>
          </div>
          <div className={`learn-banner ${completed ? 'learn-success' : ''}`}><div className="learn-icon">{completed ? <Zap size={17} /> : <Sparkles size={17} />}</div><div><small>{completed ? 'YOU MADE IT WORK!' : 'A TINY TIP OF SCIENCE'}</small><strong>{completed ? activePlushie.topology === 'parallel' ? 'Two protected branches are shining together.' : 'A complete loop lets electricity flow all the way around.' : activePlushie.topology === 'parallel' ? 'Parallel branches share the battery voltage.' : 'Electricity loves a complete loop.'}</strong><p>{completed ? activePlushie.topology === 'parallel' ? `Each 150 Ω resistor limits one whisker LED to ${branchCurrentMa} mA; together the branches draw ${parallelTotalCurrentMa} mA.` : `The battery pushes charge through the thread and ${activePlushie.lightComponent}, then back to the battery. That’s a closed circuit!` : activePlushie.topology === 'parallel' ? 'Give each whisker LED its own resistor, then join both paths across the 3V coin cell.' : 'A battery pushes electric charge through a complete path. Try each piece and see what changes!'}</p></div><div className="ohms-note">V = I × R <span>OHM&apos;S LAW</span></div></div>
          <GameLoop hasThread={placed.includes('thread')} allComponentsPresent={hasAllParts} plushieName={activePlushie.name} problem={activePlushie.problem} ability={activePlushie.ability} componentSummary={activePlushie.componentSummary} topology={activePlushie.topology} threadLength={threadLength} testResult={testResult} lastFault={lastFault} completed={completed} />
          <ProgressDashboard partners={plushieOrder.map((id) => ({ id, name: plushies[id].name, species: plushies[id].species, image: plushies[id].image, labName: plushies[id].labName }))} activePartnerId={activePlushieId} activePartnerName={activePlushie.name} completedPartnerIds={completedPlushieIds} currentParts={placed.length} requiredParts={parts.length} circuitTests={circuitTests} activity={activity} onSelectPartner={selectPartnerFromDashboard} />
          <footer className="page-footer"><span>MADE WITH CURIOSITY AT LITTLE SPARKS INSTITUTE</span><span>NO WRONG TURNS, JUST NEW DISCOVERIES <i>✦</i></span></footer>
        </div>
      </section>
    </main>
  )
}
