import Image from 'next/image'
import { ArrowUpRight, Award, BatteryCharging, BookOpen, Check, CircuitBoard, Sparkles, Star, Zap } from 'lucide-react'

type DashboardPartner = {
  id: string
  name: string
  species: string
  image: string
  labName: string
}

type CircuitActivity = {
  id: number
  partnerName: string
  result: 'passed' | 'retry'
  currentMa: number
  threadLength: number
  issue?: 'current' | 'sensor' | 'switch' | 'both'
}

type ProgressDashboardProps = {
  partners: DashboardPartner[]
  activePartnerId: string
  activePartnerName: string
  completedPartnerIds: string[]
  currentParts: number
  requiredParts: number
  circuitTests: number
  activity: CircuitActivity[]
  onSelectPartner: (partnerId: string) => void
}

const friendTones = ['friend-lilac', 'friend-peach', 'friend-mint', 'friend-blue', 'friend-rose']

export function ProgressDashboard({
  partners,
  activePartnerId,
  activePartnerName,
  completedPartnerIds,
  currentParts,
  requiredParts,
  circuitTests,
  activity,
  onSelectPartner,
}: ProgressDashboardProps) {
  const completed = new Set(completedPartnerIds)
  const activePartnerCompleted = completed.has(activePartnerId)
  const nextPartner = partners.find((partner) => !completed.has(partner.id))
  const labs = partners.map((partner, index) => {
    const isComplete = completed.has(partner.id)
    const isCurrent = partner.id === activePartnerId

    return {
      ...partner,
      number: String(index + 1).padStart(2, '0'),
      state: isComplete ? 'complete' : isCurrent ? 'current' : 'unlocked',
      detail: isComplete
        ? `Circuit complete · ${partner.labName}`
        : isCurrent
          ? `${currentParts} of ${requiredParts} components connected`
          : 'Ready to explore',
    }
  })
  const stats = [
    { label: 'Circuits completed', value: completedPartnerIds.length, note: `of ${partners.length} partners`, icon: Award, tone: 'lilac' },
    { label: 'Tests run', value: circuitTests, note: 'This session', icon: BatteryCharging, tone: 'peach' },
    { label: 'Parts connected', value: `${currentParts}/${requiredParts}`, note: `${activePartnerName}’s circuit`, icon: CircuitBoard, tone: 'mint' },
    { label: 'Badges earned', value: completedPartnerIds.length, note: completedPartnerIds.length ? 'First Spark per partner' : 'Complete a circuit to earn one', icon: Zap, tone: 'gold' },
  ]

  return (
    <>
      <div className="stats-heading" id="badge-progress"><span className="card-kicker">YOUR SESSION SNAPSHOT</span><span className="demo-tag">LIVE SESSION</span></div>
      <section className="stats-strip" aria-label="Your current workshop progress">
        {stats.map(({ label, value, note, icon: Icon, tone }) => (
          <article className="stat-card" key={label}>
            <span className={`stat-icon ${tone}`}><Icon size={17} aria-hidden="true" /></span>
            <div className="stat-copy"><span>{label}</span><strong>{typeof value === 'number' ? String(value).padStart(2, '0') : value}</strong><small>{note}</small></div>
            <ArrowUpRight className="stat-arrow" size={14} aria-hidden="true" />
          </article>
        ))}
      </section>

      <section className="progress-dashboard" aria-label="Your workshop progress">
        <div className="journey-card">
          <div className="dashboard-heading"><div><span className="card-kicker">YOUR LEARNING PATH</span><h2>Little labs, big discoveries</h2><p>Every circuit test updates your progress.</p></div><span className="journey-total"><Sparkles size={13} /> {completedPartnerIds.length} of {partners.length}</span></div>
          <div className="lab-list">
            {labs.map((lab) => (
              <article className={`lab-row ${lab.state}`} key={lab.id}>
                <span className="lab-marker">{lab.state === 'complete' ? <Check size={14} aria-hidden="true" /> : lab.number}</span>
                <div className="lab-copy"><strong>{lab.name}</strong><small>{lab.detail}</small></div>
                {lab.state === 'current' && <span className="now-tag">CURRENT</span>}
                {lab.state === 'complete' && <span className="lab-stars"><Star size={11} fill="currentColor" aria-hidden="true" /> 1</span>}
              </article>
            ))}
          </div>
          <div className="journey-foot"><BookOpen size={14} aria-hidden="true" /><span>{nextPartner ? activePartnerCompleted ? `${nextPartner.name} is ready for a new experiment.` : `Finish ${activePartnerName}’s circuit to earn a First Spark badge.` : 'Every lab partner has a completed circuit.'}</span><ArrowUpRight size={14} aria-hidden="true" /></div>
        </div>

        <section className="crew-card" id="plushie-closet" aria-labelledby="crew-title">
          <div className="dashboard-heading"><div><span className="card-kicker">THE PLUSHIE CREW</span><h2 id="crew-title">Your little lab partners</h2><p>Choose a partner to open their circuit.</p></div><span className="crew-count">{partners.length} partners</span></div>
          <div className="friend-list">
            {partners.map((partner, index) => {
              const isActive = partner.id === activePartnerId
              const isComplete = completed.has(partner.id)

              return (
                <button className={`friend-row ${isActive ? 'friend-active' : ''}`} type="button" key={partner.id} aria-pressed={isActive} onClick={() => onSelectPartner(partner.id)}>
                  <span className={`friend-avatar ${friendTones[index % friendTones.length]}`}><Image src={partner.image} alt="" width={72} height={72} sizes="52px" /></span>
                  <span className="friend-copy"><strong>{partner.name} <span>{partner.species}</span></strong><small>{isComplete ? 'Circuit complete' : isActive ? `${currentParts} of ${requiredParts} parts connected` : partner.labName}</small></span>
                  <span className={`friend-status ${isComplete ? 'status-complete' : isActive ? 'status-current' : ''}`}>{isComplete ? 'Complete' : isActive ? 'In lab' : 'Explore'}</span>
                </button>
              )
            })}
          </div>
          <div className="crew-note"><span className="crew-note-icon"><CircuitBoard size={14} aria-hidden="true" /></span><span><strong>This session</strong> {circuitTests} circuit test{circuitTests === 1 ? '' : 's'}</span><span className="crew-note-streak"><Zap size={12} fill="currentColor" aria-hidden="true" /> {completedPartnerIds.length} badges</span></div>
        </section>
      </section>

      <section className="activity-card" id="session-activity" aria-label="Recent workshop activity">
        <div className="activity-heading"><div><span className="card-kicker">THE STORY SO FAR</span><h2>Recent discoveries</h2></div><span className="activity-subtitle">Tests from this session</span></div>
        {activity.length ? <div className="activity-list">
          {activity.map((event) => (
            <article className="activity-row" key={event.id}>
              <span className={`activity-icon ${event.result === 'passed' ? 'mint' : 'peach'}`}>{event.result === 'passed' ? <Check size={16} aria-hidden="true" /> : <CircuitBoard size={16} aria-hidden="true" />}</span>
              <div className="activity-copy"><strong>{event.partnerName} {event.result === 'passed' ? 'circuit passed' : event.issue === 'sensor' ? 'sensor reading missed its target' : event.issue === 'switch' ? 'switch was open' : event.issue === 'both' ? 'circuit needs adjustments' : 'needs a shorter stitch'}</strong><small>{event.currentMa} mA at {event.threadLength} cm of thread</small></div>
              <time>Session</time>
            </article>
          ))}
        </div> : <div className="activity-empty"><CircuitBoard size={18} aria-hidden="true" /><span>Test a circuit to see your real experiment results here.</span></div>}
      </section>
    </>
  )
}
